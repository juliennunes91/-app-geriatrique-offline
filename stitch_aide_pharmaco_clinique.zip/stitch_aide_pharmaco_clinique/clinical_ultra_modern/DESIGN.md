# Design System Specification: The Ethereal Clinical Standard

## 1. Overview & Creative North Star
**Creative North Star: "The Precision Curator"**

This design system rejects the sterile, rigid grid of traditional medical software in favor of a "Precision Curator" aesthetic. It is designed to feel like a high-end editorial piece—authoritative yet breathable. We achieve this by blending the clinical reliability of Deep Navy with the fluid, forward-thinking energy of Vibrant Cyan. 

To break the "template" look, we utilize **intentional asymmetry** and **tonal layering**. Elements are not just placed; they are curated within the space. We prioritize massive negative space to reduce cognitive load for clinicians, using glassmorphic overlays to suggest depth and a "living" interface that responds to the user’s touch.

---

## 2. Colors & Surface Philosophy

The palette is anchored in high-contrast sophistication. We move beyond flat UI by treating the screen as a physical space with light and atmosphere.

### The "No-Line" Rule
**Strict Mandate:** Designers are prohibited from using 1px solid borders for sectioning. Definition must be achieved through:
*   **Background Shifts:** Using `surface-container-low` against a `background` floor.
*   **Tonal Transitions:** Defining a space through a subtle change in saturation rather than a hard stroke.

### Surface Hierarchy & Nesting
Treat the UI as stacked sheets of frosted glass.
*   **Base:** `background` (#f7f9fb)
*   **Sub-sections:** `surface-container-low` (#f2f4f6)
*   **Interactive Cards:** `surface-container-lowest` (#ffffff) for maximum "pop."
*   **Nested Content:** Use `surface-container-high` (#e6e8ea) to recess information into a parent container.

### The "Glass & Gradient" Rule
For hero sections or critical data visualizations, use **Signature Textures**. 
*   **CTA Gradient:** Transition from `primary` (#00151b) to `primary_container` (#002b36) at a 135° angle.
*   **Glassmorphism:** For floating modals or navigation rails, use `surface_container_lowest` at 70% opacity with a `20px` backdrop-blur. This allows the `vibrant cyan` of underlying accents to bleed through softly, creating a "fluid" personality.

---

## 3. Typography: Editorial Precision

We utilize a dual-typeface system to balance clinical data with human-centric design.

*   **Display & Headlines (Manrope):** Use Manrope for all `display` and `headline` levels. Its geometric yet warm curves suggest a "Cutting-edge" personality.
    *   *Visual Tip:* Use `display-lg` (3.5rem) with tight letter-spacing (-0.02em) for hero stats to create an authoritative, editorial feel.
*   **UI & Body (Inter):** Use Inter for `title`, `body`, and `label` roles. Inter’s high x-height ensures "Precision" in dense clinical readouts.
*   **The Hierarchy Shift:** Maintain a high contrast between `headline-lg` and `body-md`. This ensures the user’s eye is "anchored" to the most important data point immediately.

---

## 4. Elevation & Depth: Tonal Layering

Traditional drop shadows are too "dirty" for a clinical environment. We use light and layering to convey importance.

### The Layering Principle
Avoid shadows on standard cards. Instead, place a `surface-container-lowest` (#ffffff) card on a `surface-container-low` (#f2f4f6) background. The subtle shift in hex value provides a "Soft Minimalism" lift that feels cleaner than a shadow.

### Ambient Shadows
When an element must float (e.g., a floating action button or an active modal):
*   **Blur:** `32px` to `48px`
*   **Opacity:** 4% - 6%
*   **Color:** Use a tinted shadow based on `on_surface` (#191c1e) to ensure the shadow feels like a natural obstruction of light, not a grey smudge.

### The "Ghost Border" Fallback
If accessibility requires a container boundary, use a **Ghost Border**:
*   **Token:** `outline_variant` (#c1c7cb)
*   **Opacity:** 15%
*   **Weight:** 1px or 1.5px. Never use 100% opacity borders.

---

## 5. Components

### Buttons
*   **Primary:** A deep `primary_container` (#002b36) background with `on_primary` text. Apply a `xl` (1.5rem/24px) corner radius for a friendly, modern feel.
*   **Secondary/Action:** Use the Vibrant Cyan `secondary` (#00677d) with a glassmorphic hover state.
*   **Tertiary:** Text-only with an underline that appears only on hover, using `primary_fixed` to highlight interaction.

### Cards & Data Lists
*   **Rule:** Forbid divider lines. 
*   **Implementation:** Separate list items using 12px of vertical white space or by alternating background tones between `surface-container-low` and `surface-container-lowest`. 
*   **Corner Radius:** All cards must use `lg` (1rem/16px) or `xl` (1.5rem/24px) rounding to maintain the "Fluid" personality.

### Input Fields
*   **Style:** Minimalist. No bottom line or full box. Use a subtle `surface-container-highest` (#e0e3e5) background with `xl` rounding.
*   **Focus State:** A 2px `secondary_container` (#50d9fe) soft outer glow (not a sharp border) to indicate activity.

### Clinical Chips
*   **Design:** Use `secondary_fixed` (#b3ebff) for the background with `on_secondary_fixed` (#001f27) text. These should be pills (`full` roundness) to contrast against the `lg` card corners.

---

## 6. Do's and Don'ts

### Do:
*   **Embrace the Void:** Use more white space than you think is necessary. Space equals "Trustworthiness" and "Precision."
*   **Layer Intentionally:** Always check if a background color shift can replace a shadow or a line.
*   **Use Asymmetry:** In dashboard layouts, allow one column to be significantly wider than others to create an editorial, non-standard rhythm.

### Don't:
*   **Don't use pure black:** Use `primary` (#00151b) for depth; pure black kills the "Clinical Ultra Modern" glass effect.
*   **Don't use 1px borders:** They clutter the UI and make the system feel "out-of-the-box" and cheap.
*   **Don't crowd the edges:** Maintain a minimum 32px padding on all major containers. Clinical data needs "breathing room" to be interpreted correctly.