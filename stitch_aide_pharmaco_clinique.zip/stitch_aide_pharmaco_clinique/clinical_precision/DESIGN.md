# Design System Document: The Clinical Precision Framework

## 1. Overview & Creative North Star
**Creative North Star: The Digital Clinician**

In the world of pharmacology and high-stakes medicine, clarity is more than an aesthetic—it is a safety requirement. This design system moves away from the "generic SaaS" look to embrace a "Digital Clinician" persona: authoritative, meticulously organized, and calmly sophisticated. 

We break the standard grid-and-border template by utilizing **Tonal Architecture**. Instead of rigid lines that clutter the visual field, we use depth, layered surfaces, and editorial-grade typography to guide the eye. The result is a high-density data environment that feels breathable, premium, and inherently trustworthy. We prioritize "Expert-Density"—providing all necessary data at a glance without the cognitive load of traditional, border-heavy interfaces.

---

## 2. Colors: Tonal Depth & Hierarchy
Our palette moves beyond simple blues. We utilize deep, ink-like teals and clinical sea-foams to create a sense of profound reliability.

### The "No-Line" Rule
**Explicit Instruction:** Traditional 1px solid borders (`#CCCCCC` or similar) are strictly prohibited for sectioning or layout containment. 
*   **How to define boundaries:** Use background color shifts. A `surface_container_low` section sitting on a `surface` background provides all the definition a professional eye needs.
*   **Why:** Borders create "visual noise" that competes with complex pharmacological data. Tonal shifts create "visual zones."

### Surface Hierarchy & Nesting
Treat the UI as a series of physical, stacked layers—like frosted glass slides on a light table.
*   **Base:** `surface` (#f8fafb)
*   **Low-Level Data:** `surface_container_low` (#f2f4f5) for secondary sidebars.
*   **Primary Work Area:** `surface_container` (#eceeef) for the main content body.
*   **Elevated Focus:** `surface_container_highest` (#e1e3e4) for active modals or high-priority data widgets.

### The "Glass & Gradient" Rule
To elevate the experience, use **Glassmorphism** for floating elements (e.g., medication override panels). Use `surface_container_lowest` at 85% opacity with a `16px` backdrop-blur. 
*   **Signature Textures:** Apply a subtle linear gradient to Primary CTAs (from `primary` #004355 to `primary_container` #005c73). This provides a "jewel-like" depth that distinguishes the action from static data.

---

## 3. Typography: Editorial Authority
We utilize a dual-font strategy to balance character with clinical utility.

*   **Display & Headlines (Manrope):** Use Manrope for high-level navigation and section titles. Its geometric yet friendly curves provide a modern, high-end editorial feel that breaks the monotony of data.
*   **Functional Data (Inter):** All pharmacological data, dosages, and labels use Inter. Its tall x-height and neutral personality ensure legibility even at the `label-sm` (11px) size.

**The Hierarchy of Trust:**
*   **Headlines (`headline-lg`):** Reserved for patient names or drug categories.
*   **Data Labels (`label-md`):** Use `on_surface_variant` (#40484c) in All Caps with +2% letter spacing for a "laboratory tag" aesthetic.

---

## 4. Elevation & Depth
In this system, elevation is conveyed through **Tonal Layering**, not heavy shadows.

*   **The Layering Principle:** To create a "card," do not draw a box. Instead, place a `surface_container_lowest` (#ffffff) shape onto a `surface_container` (#eceeef) background. The 2% shift in brightness is sufficient for the human eye to perceive depth.
*   **Ambient Shadows:** For "floating" elements like dropdowns, use an ultra-diffused shadow: `y: 8px, blur: 24px, color: rgba(24, 102, 126, 0.08)`. Note the use of a blue-tinted shadow to maintain the clinical palette.
*   **The "Ghost Border" Fallback:** If accessibility requires a stroke, use the `outline_variant` (#bfc8cc) at **15% opacity**. It should be felt, not seen.

---

## 5. Components: Precision & Density

### Buttons & CTAs
*   **Primary:** Gradient fill (`primary` to `primary_container`). `0.375rem` (md) roundedness.
*   **Secondary:** No fill. `outline` (#70787d) ghost border at 20% opacity. Text color `primary`.
*   **Tertiary:** Purely text-based with a subtle `surface_container_high` hover state.

### Data Tables (The Core Component)
*   **Rule:** Forbid horizontal and vertical divider lines.
*   **Structure:** Use alternating row fills (Zebra striping) using `surface` and `surface_container_low`. 
*   **Header:** `headline-sm` typography with a `primary` color accent on the bottom 2px of the header cell only.

### Status Badges (Clinical Alerts)
*   **Contraindications:** `error_container` (#ffdad6) background with `on_error_container` (#93000a) text. Small, `full` rounded corners.
*   **Warnings:** `secondary_container` (#cce7ee) with a custom Amber accent.
*   **Stable/Safe:** `tertiary_container` (#005e64) with `on_tertiary` (#ffffff) text.

### Form Elements
*   **Inputs:** `surface_container_low` background with a `0px` border, replaced by a 2px `primary` bottom-bar that activates on focus.
*   **Micro-interaction:** Labels should shift from `body-md` to `label-sm` and change color to `primary` when the field is active.

### Medication Dosage Chips
*   Compact, high-density chips using `surface_variant`. Use `md` (6px) roundedness to distinguish them from the `full` roundedness of status badges.

---

## 6. Do’s and Don’ts

### Do
*   **Do** use white space as a structural element. If data feels cluttered, increase the padding between containers, don't add more lines.
*   **Do** use `tertiary` (#004549) for "success" or "positive" indicators to keep the palette within the clinical teal range.
*   **Do** utilize `surface_bright` to highlight the most critical data point on a dashboard (e.g., a critical lab value).

### Don't
*   **Don't** use pure black (#000000) for text. Always use `on_surface` (#191c1d) to maintain a soft, high-end feel.
*   **Don't** use "Standard" shadows. If a component looks like it's popping off the page too aggressively, reduce the shadow opacity.
*   **Don't** use high-contrast borders for table cells. It creates a "jail cell" effect that hinders rapid data scanning.